configData = {

  "token": "OTk5MzIzNTM3NTA2NTY2MTc0.GJZie8.Go27Qfq1XzYZ1tjwN4SOlWuR0azCIiKprg9IlM",

  "mongokey": "mongodb+srv://Marciel:roPbLXJEEu5w0v4c@markuus.c1awv.mongodb.net/test?authSource=admin&replicaSet=atlas-4n715z-shard-0&readPreference=primary&ssl=true",

  "prefix": "h!",

  "guild": 819320815635005480,
  
  "roles":{

    "staff": {

      "admin": 820115756527124521,

      "mod": 905819260750819338,

      "suporte": 878221184796344331,

      "staff": 832430805355593728

    },

    "equipes":{

      "equipecall": {

        "submod": 1003066124709138432,

        "staffcall": 1003064735589204098,

        "movimenta": 997634507198959686

      },

      "equipechat": {
        
        "liderchat": 1003050154066198548,

        "staffchat": 1003050263441051798, 

        "movimenta": 997634507198959686
      },

      "equipeeventos": {

        "chefeeventos": 916179057060745296,

        "apresentador": 1000388198096187403,

        "auxiliar": 1009530141703147540

      },

      "equipediv": {

        "promoters": 1003055677784199268,

        "div": 997634505328304249

      },

      "equipemidia": {

        "chefemidia": 1007277152045105173,

        "equipemidia": 1007277968529297459

      }
    },

    "adv": {

      "adv1": 998626275415564348,

      "adv2": 998626317396357120,

      "adv3": 1000388866286555227

    },

    "outras":{

      "standby": 999463609170153492,

      "verificado": 819327931700084756,

      "naoverificado": 998625382053986314,

      "mute": 930542841971753000,

      "ntb": 852633096511422495,

      "nv100" : 936401640972501052,

      "callpv": 1001583261325209731,

      "levelup": 948719479171477534

    }

  },

  "logs":{

    "chat": 1000428030151364658,

    "call": 1000428066063007855,

    "microfone": 1003358230568771614, 

    "mod": 1000428107125231646,

    "membros": 1000456498268344381,

    "cargos": 1003099164890107965,

    "usocomandos": 1005223324089073745

  },

  "chats":{

    "ticket": 820086627619569685,

    "ausencia": 1000487547769716797,

    "cmdstf": 1002537311587799124,

    "resumsemana": 1003079459731148872,

    "sugestsemana": 1007257120799993976,

    "oqprefere": 1007257060997603398,

    "ids": {

      "cmdstf": 1006712910992650360,

      "tck": 1006712909193289738

    }

  },
  
  "catego":{

    "callpv": 948717748589035540,

    "ticket": 820086443572985857

  },

  "calls":{
    
    "espera": 948804029251739658

  }
}